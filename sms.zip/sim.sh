#!/bin/bash

# 延迟30秒
sleep 30

# 切换卡槽
echo 1 > /sys/class/leds/sim:sel/brightness
echo 0 > /sys/class/leds/sim:en/brightness
echo 0 > /sys/class/leds/sim:sel2/brightness
echo 0 > /sys/class/leds/sim:en2/brightness
modprobe -r qcom-q6v5-mss
modprobe qcom-q6v5-mss
systemctl restart rmtfs
systemctl restart dbus-org.freedesktop.ModemManager1.service

# 延迟30秒
sleep 30

# 重启SIM卡
systemctl stop ModemManager
qmicli -d /dev/wwan0qmi0 --uim-sim-power-off=1
qmicli -d /dev/wwan0qmi0 --uim-sim-power-on=1
systemctl start ModemManager